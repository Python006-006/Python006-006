from django.apps import AppConfig


class FirstorderConfig(AppConfig):
    name = 'firstorder'
